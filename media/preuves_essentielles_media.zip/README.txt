PREUVES ESSENTIELLES (à mettre dans GitHub -> dossier /media)

GBF/
- schema_electrique_extrait.png : extrait du schéma (bloc AOP TL071)
- schema_pcb_kicad_layout.png : routage PCB (vue KiCad)
- pcb_3d_render.png : rendu 3D (KiCad)
- photo_carte_assemblee.png : photo carte réelle assemblée
- mesure_frequence_plot.png : courbe / mesures fréquence

PID/
- reponse_indicielle_pid.png : réponse indicielle (consigne vs vitesse)
- validation_pid.png : validation/mesures du PID
